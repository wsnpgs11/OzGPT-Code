# Corpus provenance

The supplied `prepare_data.py` identifies these Project Gutenberg sources:

- Henry Lawson, *While the Billy Boils*: ebook 7144.
- Banjo Paterson, *The Man from Snowy River and Other Verses*: ebook 213.
- Marcus Clarke, *For the Term of His Natural Life*: ebook 3424.

The original raw text files are preserved in `data/raw/`, including their supplied notices. `data/corpus.txt` is the cleaned training text. The download script uses `https://www.gutenberg.org/cache/epub/{id}/pg{id}.txt` and removes headers and footers when preparing the corpus. Consult notices in the raw source files for their distribution terms. This document records the supplied project's provenance; it does not independently certify the source IDs or licensing status.
