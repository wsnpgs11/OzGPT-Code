# app.py - a web chat page for OzGPT with Gradio
import gradio as gr

from chat import ask

BLOCKED = ["password for", "credit card", "hack into"]


def respond(message, history):
    # A very simple safety filter (Chapter 12)
    if any(word in message.lower() for word in BLOCKED):
        return "Sorry, I can't help with that request."
    if len(message) > 500:
        return "Please ask a shorter question."
    return ask(message)


demo = gr.ChatInterface(
    fn=respond,
    title="OzGPT - a tiny study helper",
    description=("A learning project. Answers may be wrong, "
                 "so always check important facts."),
    examples=["What is a firewall?", "What is a token?"],
)

if __name__ == "__main__":
    demo.launch()
