# chat.py - talk to the fine-tuned OzGPT in the terminal
import torch

from model import GPT, GPTConfig
from tokenizer import BPETokenizer

device = "cuda" if torch.cuda.is_available() else "cpu"
tok = BPETokenizer.load("data/tokenizer.json")
ckpt = torch.load("checkpoints/ozgpt_chat.pt",
                  map_location=device)
model = GPT(GPTConfig(**ckpt["config"]))
model.load_state_dict(ckpt["model"])
model.to(device).eval()

END = tok.special["<|end|>"]


def ask(question, temperature=0.3, top_k=20,
        max_tokens=120):
    prompt = f"<|user|>{question.strip()}<|assistant|>"
    ids = torch.tensor([tok.encode(prompt)], device=device)
    out = model.generate(ids, max_tokens,
                         temperature=temperature,
                         top_k=top_k, stop_id=END)
    new_ids = out[0, ids.shape[1]:].tolist()
    if END in new_ids:
        new_ids = new_ids[:new_ids.index(END)]
    return tok.decode(new_ids).strip()


if __name__ == "__main__":
    print("OzGPT chat. Type 'quit' to stop.")
    while True:
        q = input("You: ")
        if q.lower() in ("quit", "exit"):
            break
        print("OzGPT:", ask(q))
