# evaluate.py - measure OzGPT with perplexity and test prompts
import json
import math

import torch

from model import GPT, GPTConfig
from tokenizer import BPETokenizer

device = "cuda" if torch.cuda.is_available() else "cpu"
torch.manual_seed(0)
tok = BPETokenizer.load("data/tokenizer.json")


def load(path):
    ckpt = torch.load(path, map_location=device)
    m = GPT(GPTConfig(**ckpt["config"]))
    m.load_state_dict(ckpt["model"])
    return m.to(device).eval()


@torch.no_grad()
def perplexity(model, ids):
    """Average loss over the text in chunks -> exp(loss)."""
    T = model.cfg.block_size
    total, count = 0.0, 0
    for i in range(0, len(ids) - T - 1, T):
        x = torch.tensor([ids[i:i + T]], device=device)
        y = torch.tensor([ids[i + 1:i + T + 1]], device=device)
        _, loss = model(x, y)
        total += loss.item()
        count += 1
    return math.exp(total / count)


text = open("data/corpus.txt", encoding="utf-8").read()
ids = tok.encode(text)
val_ids = ids[int(0.9 * len(ids)):]      # same split as training
base = load("checkpoints/ozgpt_base.pt")
print(f"Validation perplexity: {perplexity(base, val_ids):.1f}")
print(f"Random guessing would be: {tok.vocab_size}")

# Test prompts: compare model answers with expected answers
from chat import ask  # noqa: E402

tests = [json.loads(line) for line in open(
    "data/test_questions.jsonl", encoding="utf-8")]
hits = 0
for t in tests:
    answer = ask(t["question"])
    ok = all(k.lower() in answer.lower() for k in t["keywords"])
    hits += ok
    print(f"[{'PASS' if ok else 'FAIL'}] {t['question']}")
    print("   ->", answer)
print(f"Keyword score: {hits}/{len(tests)}")
