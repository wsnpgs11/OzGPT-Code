# attention_demo.py - one attention head, step by step
import torch
import torch.nn.functional as F

torch.manual_seed(1)
T, C = 4, 8                  # 4 tokens, 8 numbers each
x = torch.randn(T, C)        # pretend these are embeddings

# Three learned layers make queries, keys and values
Wq = torch.randn(C, C) * 0.3
Wk = torch.randn(C, C) * 0.3
Wv = torch.randn(C, C) * 0.3
q, k, v = x @ Wq, x @ Wk, x @ Wv

# 1. Scores: every query compared with every key
scores = (q @ k.T) / C ** 0.5
# 2. Causal mask: no looking at future tokens
mask = torch.tril(torch.ones(T, T))
scores = scores.masked_fill(mask == 0, float("-inf"))
# 3. Softmax turns each row into weights that add to 1
weights = F.softmax(scores, dim=-1)
# 4. Output: weighted mix of the values
out = weights @ v

torch.set_printoptions(precision=2, sci_mode=False)
print(mask)
print(weights)
print("output shape:", out.shape)
