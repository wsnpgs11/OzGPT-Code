import torch

w = torch.tensor(3.0, requires_grad=True)
x = torch.tensor(2.0)
target = torch.tensor(10.0)

for step in range(5):
    pred = w * x                    # the model: pred = w * x
    loss = (pred - target) ** 2     # how wrong are we?
    loss.backward()                 # find the gradient
    with torch.no_grad():
        w -= 0.1 * w.grad           # take a small step
        w.grad.zero_()
    print(f"step {step}: w={w.item():.3f} "
          f"loss={loss.item():.3f}")
