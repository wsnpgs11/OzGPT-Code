# batch_demo.py - see inputs, targets and embeddings
import sys
import torch
import torch.nn as nn

sys.path.append(".")
from tokenizer import BPETokenizer  # noqa: E402

tok = BPETokenizer.load("data/tokenizer.json")
ids = tok.encode("The old bushman boiled the billy by the creek.")
print("ids:", ids)

block_size = 8
x = torch.tensor(ids[0:block_size])
y = torch.tensor(ids[1:block_size + 1])
for t in range(block_size):
    context = tok.decode(x[:t + 1].tolist())
    target = tok.decode([y[t].item()])
    print(f"{context!r:40} -> {target!r}")

# An embedding table: one vector of 4 numbers per token
torch.manual_seed(0)
emb = nn.Embedding(tok.vocab_size, 4)
vectors = emb(x)
print("x shape:", x.shape, " vectors shape:", vectors.shape)
print(vectors[:2])
