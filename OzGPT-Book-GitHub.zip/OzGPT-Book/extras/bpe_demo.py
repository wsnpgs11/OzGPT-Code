# bpe_demo.py - watch BPE learn merges on a tiny text
import sys
sys.path.append(".")   # so we can import tokenizer.py
from tokenizer import BPETokenizer  # noqa: E402

text = "low lower lowest newer newest " * 20
tok = BPETokenizer()
tok.train(text, vocab_size=256 + 8 + 3)   # 8 merges + 3 special
for (a, b), new_id in tok.merges.items():
    print(f"{tok.vocab[a]!r:10} + {tok.vocab[b]!r:8}"
          f" -> {tok.vocab[new_id]!r}")
ids = tok.encode("lowest newer")
print(ids)
print([tok.decode([i]) for i in ids])
