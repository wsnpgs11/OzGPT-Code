# char_tokenizer.py - the simplest possible tokeniser
text = "the cat sat on the mat"

chars = sorted(set(text))                  # the vocabulary
stoi = {ch: i for i, ch in enumerate(chars)}   # char -> id
itos = {i: ch for i, ch in enumerate(chars)}   # id -> char


def encode(s):
    return [stoi[c] for c in s]


def decode(ids):
    return "".join(itos[i] for i in ids)


print("Vocabulary:", chars)
print("Encoded   :", encode("the mat"))
print("Decoded   :", decode(encode("the mat")))
