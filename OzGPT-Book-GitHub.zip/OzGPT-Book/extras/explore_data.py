# explore_data.py - look at the corpus before training
import re
from collections import Counter

text = open("data/corpus.txt", encoding="utf-8").read()
words = re.findall(r"[a-z']+", text.lower())

print(f"Characters : {len(text):,}")
print(f"Words      : {len(words):,}")
print(f"Unique     : {len(set(words)):,}")
print(f"Characters used: {len(set(text))}")
print("Top 15 words:", Counter(words).most_common(15))

# Find strange characters that we may want to clean
odd = Counter(c for c in text if ord(c) > 126)
print("Unusual characters:", odd.most_common(10))

# Show a random sample of the text
start = len(text) // 2
print("----- sample -----")
print(text[start:start + 400])
