# memorisation_check.py - does the model copy its training text?
import sys
import torch

sys.path.append(".")
from model import GPT, GPTConfig  # noqa: E402
from tokenizer import BPETokenizer  # noqa: E402

torch.manual_seed(0)
tok = BPETokenizer.load("data/tokenizer.json")
ckpt = torch.load("checkpoints/ozgpt_base.pt", map_location="cpu")
model = GPT(GPTConfig(**ckpt["config"])).eval()
model.load_state_dict(ckpt["model"])

ids = tok.encode(open("data/corpus.txt", encoding="utf-8").read())
train_ids = ids[:int(0.9 * len(ids))]


def copy_rate(data, trials=20, prompt_len=32, gen_len=16):
    """Share of tokens that exactly match the real text."""
    match = 0
    for _ in range(trials):
        i = torch.randint(len(data) - prompt_len - gen_len, (1,))
        i = i.item()
        prompt = torch.tensor([data[i:i + prompt_len]])
        truth = data[i + prompt_len:i + prompt_len + gen_len]
        out = model.generate(prompt, gen_len, top_k=1)
        guess = out[0, prompt_len:].tolist()
        match += sum(a == b for a, b in zip(guess, truth))
    return match / (trials * gen_len)


print(f"Copy rate on training text  : {copy_rate(train_ids):.0%}")
print(f"Copy rate on validation text: "
      f"{copy_rate(ids[len(train_ids):]):.0%}")
