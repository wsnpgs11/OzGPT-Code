# plot_loss.py - draw the training and validation loss
import csv

import matplotlib.pyplot as plt

steps, train, val = [], [], []
with open("checkpoints/log.csv") as f:
    for row in csv.DictReader(f):
        steps.append(int(row["step"]))
        train.append(float(row["train_loss"]))
        val.append(float(row["val_loss"]))

plt.figure(figsize=(7, 4))
plt.plot(steps, train, label="training loss")
plt.plot(steps, val, label="validation loss")
plt.xlabel("training step")
plt.ylabel("loss")
plt.title("OzGPT pre-training")
plt.legend()
plt.grid(alpha=0.3)
plt.savefig("checkpoints/loss.png", dpi=150,
            bbox_inches="tight")
print("Saved checkpoints/loss.png")
