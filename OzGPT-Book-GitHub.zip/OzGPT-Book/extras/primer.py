import torch

a = torch.tensor([1.0, 2.0, 3.0])
b = torch.tensor([10.0, 20.0, 30.0])
print(a + b)
print(a * 2)

m = torch.zeros(2, 3)
print(m.shape)

x = torch.randn(4, 3)      # 4 rows, 3 columns
w = torch.randn(3, 2)      # 3 rows, 2 columns
y = x @ w                  # matrix multiply
print(y.shape)
