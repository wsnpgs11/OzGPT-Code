# temperature_demo.py - how temperature changes probabilities
import torch
import torch.nn.functional as F

words = [" billy", " kettle", " fire", " horse", " banana"]
logits = torch.tensor([3.0, 2.0, 1.5, 0.5, -2.0])

for temp in [0.5, 1.0, 2.0]:
    probs = F.softmax(logits / temp, dim=-1)
    line = "  ".join(f"{w.strip()}={p:.2f}"
                     for w, p in zip(words, probs))
    print(f"T={temp}: {line}")
