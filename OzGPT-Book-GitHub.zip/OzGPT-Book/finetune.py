# finetune.py - teach OzGPT to answer questions
import json
import random

import torch

from model import GPT, GPTConfig
from tokenizer import BPETokenizer

torch.manual_seed(42)
random.seed(42)
device = "cuda" if torch.cuda.is_available() else "cpu"
STEPS, BATCH, LR = 1000, 16, 3e-4

tok = BPETokenizer.load("data/tokenizer.json")
USER = tok.special["<|user|>"]
ASSIST = tok.special["<|assistant|>"]
END = tok.special["<|end|>"]

# ---- 1. Load the base model from pre-training ----
ckpt = torch.load("checkpoints/ozgpt_base.pt",
                  map_location=device)
cfg = GPTConfig(**ckpt["config"])
model = GPT(cfg)
model.load_state_dict(ckpt["model"])
model.to(device).train()


# ---- 2. Turn each Q&A pair into ids and targets ----
def make_example(q, a):
    prompt = [USER] + tok.encode(q) + [ASSIST]
    answer = tok.encode(a) + [END]
    ids = (prompt + answer)[:cfg.block_size + 1]
    x, y = ids[:-1], ids[1:]
    # Only learn from the answer: hide prompt targets
    y = [-100] * (len(prompt) - 1) + y[len(prompt) - 1:]
    return x, y


rows = [json.loads(line) for line in open(
    "data/instructions.jsonl", encoding="utf-8")]
random.shuffle(rows)
n_val = max(1, len(rows) // 10)
val_rows, train_rows = rows[:n_val], rows[n_val:]
train = [make_example(r["question"], r["answer"])
         for r in train_rows]
val = [make_example(r["question"], r["answer"])
       for r in val_rows]
print(f"Train examples: {len(train)}, val: {len(val)}")


def collate(batch):
    """Pad every example to the same length."""
    T = max(len(x) for x, _ in batch)
    xs = [x + [END] * (T - len(x)) for x, _ in batch]
    ys = [y + [-100] * (T - len(y)) for _, y in batch]
    return (torch.tensor(xs, device=device),
            torch.tensor(ys, device=device))


@torch.no_grad()
def val_loss():
    model.eval()
    _, loss = model(*collate(val))
    model.train()
    return loss.item()


# ---- 3. Fine-tuning loop (small learning rate) ----
opt = torch.optim.AdamW(model.parameters(), lr=LR,
                        weight_decay=0.0)
for step in range(STEPS + 1):
    if step % 100 == 0:
        print(f"step {step:4d} | val loss {val_loss():.3f}")
    if step == STEPS:
        break
    x, y = collate(random.sample(train, min(BATCH,
                                            len(train))))
    _, loss = model(x, y)
    opt.zero_grad(set_to_none=True)
    loss.backward()
    torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
    opt.step()

torch.save({"model": model.state_dict(),
            "config": cfg.__dict__},
           "checkpoints/ozgpt_chat.pt")
print("Saved checkpoints/ozgpt_chat.pt")
