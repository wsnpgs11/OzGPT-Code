# generate.py - write text with a trained OzGPT model
import argparse

import torch

from model import GPT, GPTConfig
from tokenizer import BPETokenizer

p = argparse.ArgumentParser()
p.add_argument("--ckpt", default="checkpoints/ozgpt_base.pt")
p.add_argument("--prompt", default="The old bushman")
p.add_argument("--tokens", type=int, default=100)
p.add_argument("--temperature", type=float, default=0.8)
p.add_argument("--top_k", type=int, default=50)
p.add_argument("--samples", type=int, default=1)
args = p.parse_args()

device = "cuda" if torch.cuda.is_available() else "cpu"


def load_model(path):
    ckpt = torch.load(path, map_location=device)
    model = GPT(GPTConfig(**ckpt["config"]))
    model.load_state_dict(ckpt["model"])
    return model.to(device).eval()


tok = BPETokenizer.load("data/tokenizer.json")
model = load_model(args.ckpt)
ids = torch.tensor([tok.encode(args.prompt)], device=device)

for s in range(args.samples):
    out = model.generate(ids, args.tokens,
                         temperature=args.temperature,
                         top_k=args.top_k)
    print(f"--- sample {s + 1} ---")
    print(tok.decode(out[0].tolist()))
