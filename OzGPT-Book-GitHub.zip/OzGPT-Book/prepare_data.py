# prepare_data.py - download and clean the OzGPT corpus
import os
import re
import urllib.request

# Public-domain Australian books from Project Gutenberg
BOOKS = {
    "billy_boils": 7144,     # Henry Lawson
    "snowy_river": 213,      # Banjo Paterson
    "natural_life": 3424,    # Marcus Clarke
}
URL = "https://www.gutenberg.org/cache/epub/{id}/pg{id}.txt"
RAW_DIR = "data/raw"
OUT_FILE = "data/corpus.txt"


def download(name, book_id):
    """Download one book (skip if we already have it)."""
    path = os.path.join(RAW_DIR, name + ".txt")
    if not os.path.exists(path):
        print("Downloading", name)
        urllib.request.urlretrieve(URL.format(id=book_id), path)
    with open(path, encoding="utf-8-sig") as f:
        return f.read()


def strip_gutenberg(text):
    """Keep only the story, not the licence header/footer."""
    start = re.search(r"\*\*\* ?START OF.*?\*\*\*", text)
    end = re.search(r"\*\*\* ?END OF.*?\*\*\*", text)
    a = start.end() if start else 0
    b = end.start() if end else len(text)
    return text[a:b]


def clean(text):
    """Simple, safe cleaning rules."""
    text = text.replace("\r\n", "\n")
    text = re.sub(r"[ \t]+", " ", text)       # extra spaces
    text = re.sub(r"\n{3,}", "\n\n", text)    # extra blank lines
    text = text.replace("_", "")              # italics marks
    return text.strip()


def main():
    os.makedirs(RAW_DIR, exist_ok=True)
    parts = []
    for name, book_id in BOOKS.items():
        text = clean(strip_gutenberg(download(name, book_id)))
        print(f"{name}: {len(text):,} characters")
        parts.append(text)
    # Add your own text files from data/extra (optional)
    extra = "data/extra"
    if os.path.isdir(extra):
        for fn in sorted(os.listdir(extra)):
            path = os.path.join(extra, fn)
            with open(path, encoding="utf-8") as f:
                parts.append(clean(f.read()))
    corpus = "\n\n".join(parts)
    with open(OUT_FILE, "w", encoding="utf-8") as f:
        f.write(corpus)
    print(f"Saved {OUT_FILE}: {len(corpus):,} characters")


if __name__ == "__main__":
    main()
