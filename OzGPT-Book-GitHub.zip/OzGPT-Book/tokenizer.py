# tokenizer.py - a small byte-level BPE tokeniser from scratch
import json
import re
from collections import Counter

# Split text into word-like pieces before BPE (like GPT-2)
SPLIT = re.compile(r"""'s|'t|'re|'ve|'m|'ll|'d| ?[A-Za-z]+"""
                   r"""| ?[0-9]+| ?[^\sA-Za-z0-9]+|\s+""")
SPECIAL = ["<|user|>", "<|assistant|>", "<|end|>"]


def count_pairs(words):
    """Count neighbouring pairs, weighted by word frequency."""
    pairs = Counter()
    for ids, freq in words.items():
        for a, b in zip(ids, ids[1:]):
            pairs[(a, b)] += freq
    return pairs


def merge(ids, pair, new_id):
    """Replace every (a, b) in ids with new_id."""
    out, i = [], 0
    while i < len(ids):
        if i < len(ids) - 1 and (ids[i], ids[i + 1]) == pair:
            out.append(new_id)
            i += 2
        else:
            out.append(ids[i])
            i += 1
    return tuple(out)


class BPETokenizer:
    def __init__(self):
        self.merges = {}                       # (a, b) -> new id
        self.vocab = {i: bytes([i]) for i in range(256)}
        self.special = {}                      # text -> id
        self.cache = {}

    def train(self, text, vocab_size, verbose=False):
        pieces = Counter(SPLIT.findall(text))
        words = {tuple(p.encode("utf-8")): n
                 for p, n in pieces.items()}
        n_merges = vocab_size - 256 - len(SPECIAL)
        for i in range(n_merges):
            pairs = count_pairs(words)
            if not pairs:
                break
            best = max(pairs, key=pairs.get)
            new_id = 256 + i
            words = {merge(w, best, new_id): n
                     for w, n in words.items()}
            self.merges[best] = new_id
            self.vocab[new_id] = (self.vocab[best[0]]
                                  + self.vocab[best[1]])
            if verbose and i % 100 == 0:
                print(i, self.vocab[new_id])
        for tok in SPECIAL:
            self.special[tok] = len(self.vocab)
            self.vocab[len(self.vocab)] = tok.encode("utf-8")

    @property
    def vocab_size(self):
        return len(self.vocab)

    def _encode_piece(self, piece):
        if piece in self.cache:
            return self.cache[piece]
        ids = tuple(piece.encode("utf-8"))
        while len(ids) >= 2:
            # pick the pair that was learned earliest
            pairs = set(zip(ids, ids[1:]))
            pair = min(pairs,
                       key=lambda p: self.merges.get(p, 1e9))
            if pair not in self.merges:
                break
            ids = merge(ids, pair, self.merges[pair])
        self.cache[piece] = list(ids)
        return list(ids)

    def encode(self, text):
        ids = []
        pattern = "(" + "|".join(map(re.escape, SPECIAL)) + ")"
        for part in re.split(pattern, text):
            if part in self.special:
                ids.append(self.special[part])
            else:
                for piece in SPLIT.findall(part):
                    ids.extend(self._encode_piece(piece))
        return ids

    def decode(self, ids):
        data = b"".join(self.vocab[i] for i in ids)
        return data.decode("utf-8", errors="replace")

    def save(self, path):
        merges = [[a, b, i] for (a, b), i in self.merges.items()]
        with open(path, "w") as f:
            json.dump({"merges": merges,
                       "special": self.special}, f)

    @classmethod
    def load(cls, path):
        tok = cls()
        with open(path) as f:
            data = json.load(f)
        for a, b, i in data["merges"]:
            tok.merges[(a, b)] = i
            tok.vocab[i] = tok.vocab[a] + tok.vocab[b]
        for text, i in data["special"].items():
            tok.special[text] = i
            tok.vocab[i] = text.encode("utf-8")
        return tok


if __name__ == "__main__":
    text = open("data/corpus.txt", encoding="utf-8").read()
    # also learn words from our Q&A data (Chapter 11)
    text += open("data/instructions.jsonl",
                 encoding="utf-8").read()
    tok = BPETokenizer()
    tok.train(text, vocab_size=2048, verbose=True)
    tok.save("data/tokenizer.json")
    sample = "G'day! The bushman boiled his billy."
    ids = tok.encode(sample)
    print(ids)
    print([tok.decode([i]) for i in ids])
    assert tok.decode(ids) == sample
    print("Vocab size:", tok.vocab_size)
