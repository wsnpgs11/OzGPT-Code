# train.py - pre-train OzGPT on the corpus
import argparse
import math
import os
import time

import torch

from model import GPT, GPTConfig
from tokenizer import BPETokenizer

p = argparse.ArgumentParser()
p.add_argument("--max_steps", type=int, default=5000)
p.add_argument("--batch_size", type=int, default=32)
p.add_argument("--lr", type=float, default=3e-4)
p.add_argument("--eval_every", type=int, default=250)
p.add_argument("--small", action="store_true",
               help="tiny model for a CPU laptop")
args = p.parse_args()

torch.manual_seed(42)
device = "cuda" if torch.cuda.is_available() else "cpu"
print("Using device:", device)

# ---- 1. Data: text -> token ids -> train/val split ----
tok = BPETokenizer.load("data/tokenizer.json")
text = open("data/corpus.txt", encoding="utf-8").read()
data = torch.tensor(tok.encode(text), dtype=torch.long)
n = int(0.9 * len(data))
train_data, val_data = data[:n], data[n:]
print(f"Tokens: {len(data):,} (train {n:,})")

# ---- 2. Model ----
if args.small:
    cfg = GPTConfig(vocab_size=tok.vocab_size, block_size=128,
                    n_layer=4, n_head=4, n_embd=128)
else:
    cfg = GPTConfig(vocab_size=tok.vocab_size)
model = GPT(cfg).to(device)
print(f"Parameters: {model.num_params() / 1e6:.2f} M")


def get_batch(split):
    """Pick random chunks; y is x shifted one token left."""
    d = train_data if split == "train" else val_data
    ix = torch.randint(len(d) - cfg.block_size - 1,
                       (args.batch_size,))
    x = torch.stack([d[i:i + cfg.block_size] for i in ix])
    y = torch.stack([d[i + 1:i + 1 + cfg.block_size]
                     for i in ix])
    return x.to(device), y.to(device)


@torch.no_grad()
def estimate_loss(iters=50):
    model.eval()
    out = {}
    for split in ["train", "val"]:
        losses = torch.zeros(iters)
        for i in range(iters):
            x, y = get_batch(split)
            _, loss = model(x, y)
            losses[i] = loss.item()
        out[split] = losses.mean().item()
    model.train()
    return out


def get_lr(step):
    """Warm up, then cosine decay to 10% of max."""
    warmup = 200
    if step < warmup:
        return args.lr * (step + 1) / warmup
    ratio = (step - warmup) / max(1, args.max_steps - warmup)
    return args.lr * (0.1 + 0.9 * 0.5 *
                      (1 + math.cos(math.pi * ratio)))


# ---- 3. Training loop ----
opt = torch.optim.AdamW(model.parameters(), lr=args.lr,
                        weight_decay=0.1)
os.makedirs("checkpoints", exist_ok=True)
best_val = float("inf")
log = open("checkpoints/log.csv", "w")
log.write("step,train_loss,val_loss\n")
t0 = time.time()

for step in range(args.max_steps + 1):
    for g in opt.param_groups:
        g["lr"] = get_lr(step)

    if step % args.eval_every == 0:
        losses = estimate_loss()
        mins = (time.time() - t0) / 60
        print(f"step {step:5d} | train {losses['train']:.3f}"
              f" | val {losses['val']:.3f} | {mins:.1f} min")
        log.write(f"{step},{losses['train']:.4f},"
                  f"{losses['val']:.4f}\n")
        log.flush()
        if losses["val"] < best_val:
            best_val = losses["val"]
            torch.save({"model": model.state_dict(),
                        "config": cfg.__dict__},
                       "checkpoints/ozgpt_base.pt")

    if step == args.max_steps:
        break
    x, y = get_batch("train")
    _, loss = model(x, y)              # forward pass
    opt.zero_grad(set_to_none=True)
    loss.backward()                    # backward pass
    torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
    opt.step()                         # update weights

print(f"Done. Best validation loss: {best_val:.3f}")
